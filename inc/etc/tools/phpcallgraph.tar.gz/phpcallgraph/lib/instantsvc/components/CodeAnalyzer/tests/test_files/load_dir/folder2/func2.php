<?php

function ClassLoaderTestFunct2() {

}
?>