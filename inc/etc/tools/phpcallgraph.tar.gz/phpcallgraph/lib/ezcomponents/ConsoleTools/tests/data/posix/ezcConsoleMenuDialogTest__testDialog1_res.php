<?php
return array (
  0 => '[0mPlease choose a possibility:

  A) Selection A
  B) Selection B
  C) Selection C
  D) Selection D
  Z) Selection Z

Select: [Z] [0m',
  1 => '[0mPlease choose a possibility:

  A) Selection A
  B) Selection B
  C) Selection C
  D) Selection D
  Z) Selection Z

Select: [Z] [0m',
  2 => 'User seletced Z
',
);

?>
