<?php
class FileDetailsTestClass4 {
    public function doSomething() {}
}
?>