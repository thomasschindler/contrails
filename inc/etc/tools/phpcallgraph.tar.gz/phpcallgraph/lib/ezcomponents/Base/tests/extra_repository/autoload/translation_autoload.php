<?php
return array(
    'extTranslationTest' => 'Translation/test.php',
);
?>
