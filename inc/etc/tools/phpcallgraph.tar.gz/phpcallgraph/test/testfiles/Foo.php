<?php
/* vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4: */

class Foo {
    /**
     * @var string $inputString
     */
    public $inputString = 'test';
    /**
     * @var int $myInteger
     */
    public $myInteger = 20;
    /**
     * @var string[] $stringarray
     */
    public $stringArray = array('1d2','a1d');
    /**
     * @var double $myDouble
     */
    public $myDouble;

    public function getInputString() {
        return $this->getInputString();
    }
}
?>
