<?php
class FileDetailsTestClass2 {
    public function doSomething() {}
}
?>