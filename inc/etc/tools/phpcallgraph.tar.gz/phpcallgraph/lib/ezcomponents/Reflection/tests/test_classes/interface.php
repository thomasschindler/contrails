<?php
interface IInterface {

}
?>