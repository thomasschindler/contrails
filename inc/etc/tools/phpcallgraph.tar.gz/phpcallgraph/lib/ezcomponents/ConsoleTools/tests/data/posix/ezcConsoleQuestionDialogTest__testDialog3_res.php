<?php
return array (
  0 => '[0mIs the answer to everything 42? (y/n) [y] [0m',
  1 => '[0mIs the answer to everything 42? (y/n) [y] [0m',
  2 => 'You are so right! Don\'t forget your towel! :)
',
);

?>
