<?php

function ClassLoaderTestFunct3() {

}
?>