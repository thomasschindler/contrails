<?php
class FileDetailsTestClass3 {
    public function doSomething() {}
}
?>