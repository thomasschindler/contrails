<?php

return array (
  0 => '[0mPlease enter your email address:  [0m',
  1 => '[0mPlease enter your email address:  [0m',
  2 => 'User manually aborted\\ņ',
);

?>