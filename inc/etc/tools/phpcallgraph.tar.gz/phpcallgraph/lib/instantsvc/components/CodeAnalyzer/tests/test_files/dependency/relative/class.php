<?php
class DepTestRelative {
	public function doSomething() {} 
}
?>