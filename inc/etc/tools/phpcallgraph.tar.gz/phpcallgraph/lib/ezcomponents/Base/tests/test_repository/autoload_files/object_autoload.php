<?php
return array(
	'Object' => 'object/object.php',
);
?>
