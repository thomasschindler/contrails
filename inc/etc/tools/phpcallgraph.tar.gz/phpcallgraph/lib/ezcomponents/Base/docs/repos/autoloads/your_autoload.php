<?php
      return array (
           'erYourClass1' => 'You/yourclass1.php',
           'erYourClass2' => 'You/yourclass2.php',
       );
?>
