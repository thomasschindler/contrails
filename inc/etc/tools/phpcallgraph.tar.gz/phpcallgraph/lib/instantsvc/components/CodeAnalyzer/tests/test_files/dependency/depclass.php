<?php
require_once(dirname(__FILE__).'/class.php');

class DepTest2 extends DepTest1  {
	public function doSomething() {} 
}
?>