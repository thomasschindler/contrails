<?php

class TestMethods2 extends TestMethods {

    public function m2() {

    }

    public function newMethod() {}
}

?>