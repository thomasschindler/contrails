<?php
class FileDetailsTestClass {
    public function doSomething() {}
}
?>