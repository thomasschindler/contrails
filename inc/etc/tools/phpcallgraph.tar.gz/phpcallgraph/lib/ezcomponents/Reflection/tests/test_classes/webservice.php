<?php
/**
 * This is the short description
 *
 * This is the long description with may be additional infos and much more lines
 * of text.
 *
 * Empty lines are valide to.
 *
 * foo bar
 *
 * @webservice
 * @foobar bar foo 1 2 3 4
 */
class TestWebservice {
    private $prop1;
    protected $prop2;
    public $prop3;
}

?>