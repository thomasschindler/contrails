<?php
/**
 * 
 * 
 * @author Falko Menge <fakko at users dot sourceforge dot net>
 * @copyright 2009 Falko Menge
 * @package StaticReflection
 */

/**
 * 
 * 
 * @package 
 * @subpackage
 */
class staticReflectionMethod
    extends ReflectionFunctionAbstract
    implements Reflector
{

    /**
     * 
     */
    const IS_STATIC = 1;

    /**
     * 
     */
    const IS_PUBLIC = 256;

    /**
     * 
     */
    const IS_PROTECTED = 512;

    /**
     * 
     */
    const IS_PRIVATE = 1024;

    /**
     * 
     */
    const IS_ABSTRACT = 2;

    /**
     * 
     */
    const IS_FINAL = 4;

    /**
     * @var 
     */
    public $name;

    /**
     * @var 
     */
    public $class;

    /**
     * 
     * 
     * @param mixed class 
     * @param mixed name 
     * @param mixed return 
     * @return mixed
     */
    public static function export( $class, $name, $return = null )
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * Constructor.
     * 
     * Will be called on each newly-created object.
     */
    public function __construct( $class_or_method, $name = null )
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * Returns the string representation of the current object.
     * 
     * @return string
     */
    public function __toString()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function isPublic()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function isPrivate()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function isProtected()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function isAbstract()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function isFinal()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function isStatic()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function isConstructor()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function isDestructor()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function getModifiers()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @param mixed object 
     * @param mixed args 
     * @return mixed
     */
    public function invoke( $object, $args )
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @param mixed object 
     * @param array args 
     * @return mixed
     */
    public function invokeArgs( $object, array $args )
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function getDeclaringClass()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function getPrototype()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * Creates a copy of the object.
     * 
     * An object copy is created by using the clone keyword (which calls the
     * object's __clone() method if possible). The method cannot be called
     * directly.
     * @return ReflectionFunctionAbstract
     */
    final private function __clone()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function isInternal()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function isUserDefined()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function getName()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function getFileName()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function getStartLine()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function getEndLine()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function getDocComment()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function getStaticVariables()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function returnsReference()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function getParameters()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function getNumberOfParameters()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function getNumberOfRequiredParameters()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function getExtension()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function getExtensionName()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }

    /**
     * 
     * 
     * @return mixed
     */
    public function isDeprecated()
    {
        //TODO: Add implementation
        throw new Exception(
            'Method __CLASS__::__METHOD__ is not implemented.'
        );
    }
}

