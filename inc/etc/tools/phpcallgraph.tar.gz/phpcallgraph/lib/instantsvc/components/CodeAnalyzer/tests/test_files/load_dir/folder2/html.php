<html>
<body>
this is a html body
<?php
    class ClassLoaderTestClassHtml {

    }

?>
</body>

</html>