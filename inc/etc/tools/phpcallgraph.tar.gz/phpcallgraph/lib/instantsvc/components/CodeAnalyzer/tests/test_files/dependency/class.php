<?php
class DepTest1 {
	public function doSomething() {} 
}

function depFunc1() {

}

function depFunc2() {

}
?>