#!/bin/sh
phpunit ezcCodeAnalyzerSuite dev-suite.php
