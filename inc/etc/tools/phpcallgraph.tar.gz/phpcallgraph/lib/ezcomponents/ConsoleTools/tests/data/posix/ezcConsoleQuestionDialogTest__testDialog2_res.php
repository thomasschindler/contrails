<?php
return array (
  0 => '[0mHow old are you? (<int>) [0m',
  1 => '[0mHow old are you? (<int>) [0m',
  2 => '[0mHow old are you? (<int>) [0m',
  3 => '[0mHow old are you? (<int>) [0m',
  4 => 'Hey, you\'re still young! :)
',
);

?>
