<?php
require_once('relative/class.php');

class DepTest2 extends DepTestRelative  {
	public function doSomething() {} 
}
?>