<?php

class BaseClass {

    public function doSomeMetaProgramming()
	{
		return true;
	}
}

?>