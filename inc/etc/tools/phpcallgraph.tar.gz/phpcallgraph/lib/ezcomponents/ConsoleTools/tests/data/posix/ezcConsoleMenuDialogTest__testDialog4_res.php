<?php

return array (
  0 => '[0mPlease choose a possibility:

  A) Selection A
  B) Selection B
  C) Selection C
  D) Selection D
  Z) Selection Z

Select: [Z] [0m',
  1 => 'User seletced A
[0mPlease choose a possibility:

  A) Selection A
  B) Selection B
  C) Selection C
  D) Selection D
  Z) Selection Z

Select: [Z] [0m',
  2 => '[0mPlease choose a possibility:

  A) Selection A
  B) Selection B
  C) Selection C
  D) Selection D
  Z) Selection Z

Select: [Z] [0m',
  3 => 'User manually aborted
User quitted
',
);

?>