<?php

return array (
  0 => '[0mPlease enter your email address:  [0m',
  1 => '[0mPlease enter your email address:  [0m',
  2 => '[0mPlease enter your email address:  [0m',
  3 => '[0mPlease enter your email address:  [0m',
  4 => 'The email address is foo.bar@example.com.
',
);

?>