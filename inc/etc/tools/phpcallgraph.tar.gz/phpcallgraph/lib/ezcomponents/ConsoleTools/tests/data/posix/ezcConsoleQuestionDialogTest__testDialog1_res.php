<?php
 return array (
  0 => '[0mDo you want to proceed? (y/n) [n] [0m',
  1 => '[0mDo you want to proceed? (y/n) [n] [0m',
  2 => 'The user decided to proceed.
',
);
?>
